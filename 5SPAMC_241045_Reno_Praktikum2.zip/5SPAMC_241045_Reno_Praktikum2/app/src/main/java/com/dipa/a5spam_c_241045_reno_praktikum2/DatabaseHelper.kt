package com.dipa.a5spam_c_241045_reno_praktikum2

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DatabaseHelper(context: Context) :
    SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object {
        private const val DATABASE_NAME = "praktikum.db"
        private const val DATABASE_VERSION = 1
        private const val TABLE_NAME = "mahasiswa"
    }

    override fun onCreate(db: SQLiteDatabase) {
        val createTable = """
            CREATE TABLE $TABLE_NAME (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                nim TEXT NOT NULL,
                nama TEXT NOT NULL,
                alamat TEXT,
                jurusan TEXT,
                nomor_hp TEXT
            )
        """.trimIndent()

        db.execSQL(createTable)

        val dataAwal = listOf(
            arrayOf("241001", "Ahmad Fauzi", "Makassar", "Sistem Informasi", "081234567890"),
            arrayOf("241002", "Siti Nurhaliza", "Gowa", "Manajemen Informatika", "081234567891"),
            arrayOf("241003", "Budi Santoso", "Maros", "Sistem Informasi", "081234567892")
        )

        for (data in dataAwal) {
            val values = ContentValues().apply {
                put("nim", data[0])
                put("nama", data[1])
                put("alamat", data[2])
                put("jurusan", data[3])
                put("nomor_hp", data[4])
            }

            db.insert(TABLE_NAME, null, values)
        }
    }

    override fun onUpgrade(
        db: SQLiteDatabase,
        oldVersion: Int,
        newVersion: Int
    ) {
        db.execSQL("DROP TABLE IF EXISTS $TABLE_NAME")
        onCreate(db)
    }

    fun tambahMahasiswa(mahasiswa: Mahasiswa): Boolean {
        val db = writableDatabase

        val values = ContentValues().apply {
            put("nim", mahasiswa.nim)
            put("nama", mahasiswa.nama)
            put("alamat", mahasiswa.alamat)
            put("jurusan", mahasiswa.jurusan)
            put("nomor_hp", mahasiswa.nomorHp)
        }

        return db.insert(TABLE_NAME, null, values) != -1L
    }

    fun getAllMahasiswa(): ArrayList<Mahasiswa> {
        val daftar = ArrayList<Mahasiswa>()
        val db = readableDatabase

        val cursor = db.rawQuery(
            "SELECT * FROM $TABLE_NAME ORDER BY id DESC",
            null
        )

        cursor.use {
            while (it.moveToNext()) {
                daftar.add(
                    Mahasiswa(
                        id = it.getInt(it.getColumnIndexOrThrow("id")),
                        nim = it.getString(it.getColumnIndexOrThrow("nim")),
                        nama = it.getString(it.getColumnIndexOrThrow("nama")),
                        alamat = it.getString(it.getColumnIndexOrThrow("alamat")) ?: "",
                        jurusan = it.getString(it.getColumnIndexOrThrow("jurusan")) ?: "",
                        nomorHp = it.getString(it.getColumnIndexOrThrow("nomor_hp")) ?: ""
                    )
                )
            }
        }

        return daftar
    }
}
