package com.dipa.a5spam_c_241045_reno_praktikum2

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ListView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var databaseHelper: DatabaseHelper
    private lateinit var adapter: MahasiswaAdapter

    private lateinit var edtNim: EditText
    private lateinit var edtNama: EditText
    private lateinit var edtAlamat: EditText
    private lateinit var edtJurusan: EditText
    private lateinit var edtNomorHp: EditText
    private lateinit var listView: ListView

    private val daftarMahasiswa = ArrayList<Mahasiswa>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        databaseHelper = DatabaseHelper(this)

        edtNim = findViewById(R.id.edtNim)
        edtNama = findViewById(R.id.edtNama)
        edtAlamat = findViewById(R.id.edtAlamat)
        edtJurusan = findViewById(R.id.edtJurusan)
        edtNomorHp = findViewById(R.id.edtNomorHp)

        listView = findViewById(R.id.listViewMahasiswa)

        val btnSimpan = findViewById<Button>(R.id.btnSimpan)

        adapter = MahasiswaAdapter(this, daftarMahasiswa)
        listView.adapter = adapter

        tampilkanData()

        btnSimpan.setOnClickListener {
            simpanData()
        }
    }

    private fun simpanData() {
        val nim = edtNim.text.toString().trim()
        val nama = edtNama.text.toString().trim()
        val alamat = edtAlamat.text.toString().trim()
        val jurusan = edtJurusan.text.toString().trim()
        val nomorHp = edtNomorHp.text.toString().trim()

        if (
            nim.isEmpty() ||
            nama.isEmpty() ||
            alamat.isEmpty() ||
            jurusan.isEmpty() ||
            nomorHp.isEmpty()
        ) {
            Toast.makeText(
                this,
                "Semua data harus diisi!",
                Toast.LENGTH_SHORT
            ).show()
            return
        }

        val mahasiswa = Mahasiswa(
            nim = nim,
            nama = nama,
            alamat = alamat,
            jurusan = jurusan,
            nomorHp = nomorHp
        )

        val berhasil = databaseHelper.tambahMahasiswa(mahasiswa)

        if (berhasil) {
            Toast.makeText(
                this,
                "Data mahasiswa berhasil disimpan",
                Toast.LENGTH_SHORT
            ).show()

            kosongkanForm()
            tampilkanData()
        } else {
            Toast.makeText(
                this,
                "Gagal menyimpan data",
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    private fun tampilkanData() {
        daftarMahasiswa.clear()
        daftarMahasiswa.addAll(databaseHelper.getAllMahasiswa())
        adapter.notifyDataSetChanged()
    }

    private fun kosongkanForm() {
        edtNim.text.clear()
        edtNama.text.clear()
        edtAlamat.text.clear()
        edtJurusan.text.clear()
        edtNomorHp.text.clear()
        edtNim.requestFocus()
    }
}
