package com.dipa.a5spam_c_241045_reno_praktikum2

data class Mahasiswa(
    val id: Int = 0,
    val nim: String,
    val nama: String,
    val alamat: String,
    val jurusan: String,
    val nomorHp: String
)
